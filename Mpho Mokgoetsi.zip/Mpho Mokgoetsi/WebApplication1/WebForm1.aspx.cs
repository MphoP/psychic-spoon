﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void buttonSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
                con.Open();

                string Insert = "Insert Into Clients(Name, Surname, Email, Contact) Values(@Name, @Surname, @Email, @Contact)";
                SqlCommand cmd = new SqlCommand(Insert, con);

                cmd.Parameters.AddWithValue("@Name", textName.Text);
                cmd.Parameters.AddWithValue("@Surname", textSurname.Text);
                cmd.Parameters.AddWithValue("@Email", textEmail.Text);
                cmd.Parameters.AddWithValue("@Contact", textContact.Text);
                cmd.ExecuteNonQuery();

                Response.Redirect("Home.aspx");
                con.Close();
            }
            catch(Exception ex)
            {
                Response.Write(ex);
            }

        }
    }
}